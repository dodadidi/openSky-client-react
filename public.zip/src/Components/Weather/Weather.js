import { Link } from 'react-router-dom'
import {weatherService} from '../../Service/WeatherService'
import { useState, useEffect, React} from 'react'

const Weather = () => {
  const [weather, setWeather] = useState(null)

  useEffect(() => {
    getWeather()
})
  const getWeather= async () =>{
    const data = await weatherService.getByCity("Tel-Aviv")
    console.log(data)
    setWeather(data)
  }
  
  return (
    <div>
      {/* <a href='/'>Go Back</a> */}
      <Link to='/'>Go Back</Link>
    </div>
  )
}

export default Weather