import { Link } from 'react-router-dom'


const Statistics = () => {
  return (
    <div>
      <h4>Statistics</h4>
      {/* <a href='/'>Go Back</a> */}
      <Link to='/'>Go Back</Link>
    </div>
  )
}

export default Statistics